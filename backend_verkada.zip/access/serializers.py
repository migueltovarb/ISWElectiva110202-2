from rest_framework import serializers

class LectorSerializer(serializers.ModelSerializer):
    class Meta:
        fields = ['id', 'user', 'door', 'created_at']
